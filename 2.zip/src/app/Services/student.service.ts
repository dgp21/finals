import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs';
import { Student } from '../student';

@Injectable()
export class StudentService {
  private studentsUrl = 'api/students';  // URL to web api

  constructor(private http: Http) { }

  getStudents(): Observable<Student[]> {
    return this.http.get(this.studentsUrl)
     .map(this.extractData)
     .catch(this.handleError);
  }

  getStudent(id: number): Observable<Student> {
    const url = `${this.studentsUrl}/${id}`;
    return this.http.get(url)
     .map(this.extractData)
     .catch(this.handleError);
  }

  addStudent(student: Student): Observable<Student> {
    return this.http.post(this.studentsUrl, student)
     .map(this.extractData)
     .catch(this.handleError);
  }

  updateStudent(student: Student): Observable<Student> {
    const url = `${this.studentsUrl}/${student.id}`;
    return this.http.put(url, student)
     .map(this.extractData)
     .catch(this.handleError);
  }

  deleteStudent(id: number): Observable<void> {
    const url = `${this.studentsUrl}/${id}`;
    return this.http.delete(url)
     .map(() => null)
     .catch(this.handleError);
  }

  private extractData(res: Response) {
    const body = res.json();
    return body.data || {};
  }

  private handleError(error: any) {
    const errMsg = error.message || 'Server error';
    console.error(errMsg); // log to console instead
    return Observable.throw(errMsg);
  }
}
